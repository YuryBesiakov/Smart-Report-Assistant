"""Flask‑Anwendung für den Smart‑Report Assistant.

Dieses Modul implementiert die Routen für Dateiupload und Berichtserstellung.
Beim Upload wird eine CSV‑Datei verarbeitet, Diagramme werden erstellt und
eine Zusammenfassung mithilfe von GPT generiert. Das Ergebnis wird als
HTML‑Seite dargestellt.
"""

from __future__ import annotations

import os
from pathlib import Path

from flask import Flask, render_template, request
from werkzeug.utils import secure_filename
import pandas as pd

from .report_generator import generate_plots, generate_summary


def create_app() -> Flask:
    """Erstellt die Flask‑Anwendung und konfiguriert Upload‑Ordner."""
    app = Flask(__name__)

    # Verzeichnisse für Uploads und Diagramme
    base_dir = Path(__file__).resolve().parent.parent  # Projektwurzel
    upload_dir = base_dir / "data" / "uploads"
    plot_dir = Path(__file__).resolve().parent / "static" / "plots"

    upload_dir.mkdir(parents=True, exist_ok=True)
    plot_dir.mkdir(parents=True, exist_ok=True)

    @app.route("/", methods=["GET", "POST"])
    def index():
        """Startseite mit Upload‑Formular und Berichtsansicht."""
        if request.method == "POST":
            file = request.files.get("file")
            if not file:
                return render_template("upload.html", error="Bitte wählen Sie eine Datei aus.")
            filename = secure_filename(file.filename)
            if not filename.lower().endswith(".csv"):
                return render_template("upload.html", error="Bitte laden Sie eine CSV‑Datei hoch.")
            file_path = upload_dir / filename
            file.save(file_path)
            # Lese CSV in DataFrame
            try:
                df = pd.read_csv(file_path)
            except Exception as exc:
                return render_template(
                    "upload.html",
                    error=f"Die Datei konnte nicht gelesen werden: {exc}",
                )
            # Erzeuge Diagramme
            try:
                bar_path, line_path = generate_plots(df, str(plot_dir))
            except Exception as exc:
                return render_template(
                    "upload.html",
                    error=f"Fehler beim Erzeugen der Diagramme: {exc}",
                )
            # Erzeuge Zusammenfassung
            summary = generate_summary(df)
            # Dateinamen relativ zum static‑Ordner bestimmen
            bar_name = os.path.basename(bar_path)
            line_name = os.path.basename(line_path)
            return render_template(
                "report.html",
                summary=summary,
                bar_plot_name=bar_name,
                line_plot_name=line_name,
            )
        return render_template("upload.html")

    return app


if __name__ == "__main__":
    # Lokaler Start der Anwendung
    application = create_app()
    # Debug‑Modus aktivieren für lokale Entwicklung
    application.run(debug=True)