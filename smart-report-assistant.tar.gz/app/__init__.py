"""Initialisiert das Flask‑Paket für Smart‑Report Assistant.

Dieses Modul dient vor allem dazu, Python mitzuteilen, dass der Ordner
`app` ein Package ist. Alle anderen Komponenten (Flask‑App, Report‑Logik,
Templates) befinden sich in Untermodulen.
"""

from importlib import resources as _resources  # noqa: F401  (verhindert Linterwarnung)
