"""Hilfsfunktionen zur Erzeugung von Diagrammen und zur GPT‑basierten
Zusammenfassung von Datensätzen.

Dieses Modul kapselt alle Operationen, die vom Flask‑Controller genutzt
werden: Erstellen von Balken‑ und Liniendiagrammen aus einer pandas
DataFrame sowie die Kommunikation mit der OpenAI‑API, um eine
zusammenfassende Beschreibung der numerischen Daten zu erhalten.
"""

from __future__ import annotations

import os
import uuid
from typing import Tuple, Optional

import pandas as pd
import matplotlib

# Verwende den 'Agg'-Backend, um Matplotlib ohne GUI nutzen zu können
matplotlib.use("Agg")
import matplotlib.pyplot as plt  # noqa: E402  # import nach Backend‑Umstellung

try:
    import openai  # type: ignore
except ImportError:
    openai = None  # Fallback, wenn openai nicht installiert ist

def generate_plots(df: pd.DataFrame, output_dir: str) -> Tuple[str, str]:
    """Erzeugt Balken‑ und Liniendiagramme aus dem gegebenen DataFrame.

    Der Algorithmus versucht, sinnvolle Spalten auszuwählen:

    * Die erste numerische Spalte dient als Grundlage für beide Diagramme.
    * Falls es eine Datums‑ oder Zeitspalte gibt, wird sie für das Liniendiagramm
      genutzt und auf Monatsbasis gruppiert.
    * Das Balkendiagramm zeigt die obersten 10 Zeilen der ersten numerischen
      Spalte sortiert nach Wert.

    Args:
        df: Eingabedaten als pandas DataFrame.
        output_dir: Verzeichnis, in dem die Bilder gespeichert werden sollen.

    Returns:
        Ein Tupel aus zwei Dateipfaden (bar_plot_path, line_plot_path).
    """

    os.makedirs(output_dir, exist_ok=True)

    # Suche nach numerischen Spalten
    numeric_cols = df.select_dtypes(include=["number"]).columns.tolist()
    if not numeric_cols:
        raise ValueError("Der Datensatz enthält keine numerischen Spalten und kann nicht visualisiert werden.")

    first_numeric = numeric_cols[0]

    # Balkendiagramm: Top 10 Werte der ersten numerischen Spalte
    sorted_df = df.sort_values(by=first_numeric, ascending=False).head(10)
    plt.figure(figsize=(8, 4.5))
    plt.bar(sorted_df.index.astype(str), sorted_df[first_numeric], color="#4C72B0")
    plt.xticks(rotation=45, ha="right")
    plt.title(f"Top‑{min(10, len(sorted_df))} Werte von {first_numeric}")
    plt.ylabel(first_numeric)
    plt.tight_layout()
    bar_filename = f"bar_chart_{uuid.uuid4().hex}.png"
    bar_path = os.path.join(output_dir, bar_filename)
    plt.savefig(bar_path)
    plt.close()

    # Liniendiagramm: Wenn eine Datums‑Spalte existiert, gruppieren nach Monat
    date_col: Optional[str] = None
    for col in df.columns:
        # Versuche die Spalte als Datum zu interpretieren
        try:
            parsed = pd.to_datetime(df[col], errors="coerce")
        except Exception:
            continue
        # Wenn es genügend valide Einträge gibt, wähle diese Spalte
        if parsed.notna().sum() > len(df) * 0.5:
            date_col = col
            break

    plt.figure(figsize=(8, 4.5))
    if date_col is not None:
        parsed_dates = pd.to_datetime(df[date_col], errors="coerce")
        # Gruppe nach Monat
        grouped = df.copy()
        grouped["_parsed_date"] = parsed_dates.dt.to_period("M")
        # Aggregiere die numerische Spalte über die Gruppierung (Summe)
        agg_series = grouped.groupby("_parsed_date")[first_numeric].sum()
        # Konvertiere PeriodIndex zu string für plotting
        x_vals = agg_series.index.astype(str)
        y_vals = agg_series.values
        plt.plot(x_vals, y_vals, marker="o", color="#55A868")
        plt.xticks(rotation=45, ha="right")
        plt.title(f"Zeitverlauf von {first_numeric} (monatlich)")
        plt.ylabel(first_numeric)
        plt.xlabel("Monat")
    else:
        # Kein Datum vorhanden, verwende Index als x‑Achse
        plt.plot(df.index.astype(str), df[first_numeric], marker="o", color="#55A868")
        plt.xticks(rotation=45, ha="right")
        plt.title(f"Verlauf von {first_numeric}")
        plt.ylabel(first_numeric)
        plt.xlabel("Index")
    plt.tight_layout()
    line_filename = f"line_chart_{uuid.uuid4().hex}.png"
    line_path = os.path.join(output_dir, line_filename)
    plt.savefig(line_path)
    plt.close()

    return bar_path, line_path


def generate_summary(df: pd.DataFrame) -> str:
    """Erzeugt mithilfe von OpenAI eine Zusammenfassung des Datensatzes.

    Aus Performance‑Gründen wird nicht der gesamte Datensatz an die API
    übertragen. Stattdessen werden grundlegende Statistiken jeder
    numerischen Spalte berechnet und als Kontext an das Modell gesendet.

    Args:
        df: Eingabedaten als pandas DataFrame.

    Returns:
        Eine deutschsprachige Zusammenfassung mit wichtigen Erkenntnissen.
    """

    # Bereite eine Beschreibung der numerischen Spalten vor
    numeric_cols = df.select_dtypes(include=["number"]).columns.tolist()
    summary_parts: list[str] = []
    for col in numeric_cols:
        col_mean = df[col].mean()
        col_min = df[col].min()
        col_max = df[col].max()
        summary_parts.append(
            f"{col}: Mittelwert {col_mean:.2f}, Minimum {col_min}, Maximum {col_max}."
        )
    dataset_summary = "\n".join(summary_parts)

    # Fallback‑Text, falls openai nicht verfügbar ist
    fallback_report = (
        "Dies ist eine einfache Zusammenfassung der numerischen Spalten:\n"
        + dataset_summary
    )

    # Wenn openai nicht installiert oder kein API‑Key vorhanden, gebe Fallback zurück
    if openai is None:
        return fallback_report

    api_key = os.environ.get("OPENAI_API_KEY")
    if not api_key:
        # Kein Schlüssel gesetzt, verwende Fallback
        return fallback_report

    openai.api_key = api_key

    prompt = (
        "Du bist ein Datenanalyst und sollst einen kurzen Bericht zu einem "
        "Geschäftsdatensatz erstellen. Anbei findest du eine Zusammenfassung der "
        "numerischen Spalten eines Datensatzes. Fasse die wichtigsten Trends und "
        "Auffälligkeiten knapp in deutscher Sprache zusammen und gib nach Möglichkeit "
        "zwei bis drei Empfehlungen ab.\n\n"
        f"Datensatz‑Zusammenfassung:\n{dataset_summary}\n\nBericht:"
    )

    try:
        response = openai.ChatCompletion.create(
            model="gpt-3.5-turbo",
            messages=[
                {"role": "system", "content": "Du bist ein hilfreicher Assistent, der Daten zusammenfasst."},
                {"role": "user", "content": prompt},
            ],
            max_tokens=250,
            temperature=0.7,
        )
        text = response["choices"][0]["message"]["content"].strip()
        return text
    except Exception:
        # Wenn bei der API‑Anfrage ein Fehler auftritt, gebe Fallback zurück
        return fallback_report