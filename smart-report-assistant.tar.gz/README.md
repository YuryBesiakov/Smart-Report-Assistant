# Smart‑Report Assistant

**Smart‑Report Assistant** ist ein kleines Werkzeug zur automatisierten Berichterstellung aus strukturierten Daten. Sie laden eine CSV‑Datei mit Metriken hoch (z.&nbsp;B. Kundenzahlen, Risikoscore oder Verluste), das Werkzeug erstellt daraus automatisch Diagramme und eine textuelle Zusammenfassung und zeigt alles in einem HTML‑Bericht an. Die Visualisierung erfolgt mit Matplotlib, die Zusammenfassung erzeugt ein GPT‑Modell von OpenAI.

## Funktionsumfang (MVP)

- **Dateiupload:** Benutzer können eine CSV‑Datei hochladen, die mindestens eine Datums‑/Monatsspalte und eine oder mehrere numerische Metriken enthält.
- **Automatische Diagramme:** Aus der ersten numerischen Spalte wird ein Balkendiagramm mit den größten Werten erzeugt, aus einer möglichen Datums‑Spalte und der ersten numerischen Spalte wird ein Liniendiagramm über die Zeit erstellt.
- **GPT‑Zusammenfassung:** Die wichtigsten Kennzahlen aus dem Datensatz werden extrahiert und an die OpenAI‑API geschickt, um eine knappe, deutschsprachige Zusammenfassung mit Highlights und optionalen Empfehlungen zu erhalten.
- **HTML‑Bericht:** Ergebnisse und Grafiken werden in einem HTML‑Report gerendert. Bei Bedarf kann der Bericht als PDF gespeichert werden.

## Projektstruktur

Das Projekt folgt einer üblichen Flask‑Struktur mit `templates` für Jinja2‑Vorlagen und `static` für statische Inhalte wie Bilder und CSS. Die Flask‑Dokumentation zeigt ein vergleichbares Layout mit getrennten Verzeichnissen für Anwendungscode, Templates und statische Dateien【612369046759096†L61-L78】. Die wichtigsten Dateien und Ordner des Projekts:

```text
smart-report-assistant/
├── README.md                     # Diese Projektbeschreibung
├── requirements.txt              # Python‑Abhängigkeiten
├── .gitignore                    # Ausschließen von Build‑Artefakten
├── data/
│   └── beispiel.csv             # Beispiel‑CSV für Tests
└── app/
    ├── __init__.py             # Initialisiert das Flask‑Paket
    ├── main.py                 # Flask‑Applikation mit Upload‑Route
    ├── report_generator.py     # Logik für Plot‑Erstellung und GPT‑Zusammenfassung
    ├── templates/
    │   ├── upload.html         # Upload‑Formular
    │   └── report.html         # Berichtsvorlage
    └── static/
        └── plots/              # Hier werden erzeugte Diagramme gespeichert
```

## Installation

1. Stellen Sie sicher, dass Sie eine aktuelle Python‑Version installiert haben (getestet mit Python 3.10).
2. Klonen oder laden Sie dieses Repository und wechseln Sie in das Projektverzeichnis:
   ```bash
   git clone <repository-url>
   cd smart-report-assistant
   ```
3. Erstellen Sie eine virtuelle Umgebung (optional, aber empfohlen) und installieren Sie die Abhängigkeiten:
   ```bash
   python -m venv venv
   source venv/bin/activate  # unter Windows: venv\Scripts\activate
   pip install -r requirements.txt
   ```
4. Setzen Sie Ihre OpenAI‑API‑Schlüssel als Umgebungsvariable `OPENAI_API_KEY`:
   ```bash
   export OPENAI_API_KEY=sk-...
   ```
5. Starten Sie die Anwendung im Entwicklungsmodus:
   ```bash
   python -m app.main
   ```
   Die Applikation ist nun unter `http://localhost:5000` erreichbar.

## Verwendung

1. Öffnen Sie die Startseite im Browser (`/`).
2. Wählen Sie eine CSV‑Datei aus und klicken Sie auf **Bericht erstellen**.
3. Die Anwendung liest die Datei, generiert Diagramme, ruft die GPT‑API auf und stellt einen Bericht dar. Bilder werden im Ordner `app/static/plots` gespeichert.

## Anpassungen

- **Diagramme anpassen:** In `app/report_generator.py` können Sie festlegen, welche Spalten für die Diagramme verwendet werden. Der aktuelle Code wählt die erste numerische Spalte und optional eine Datums‑Spalte.
- **Berichtslayout:** Die HTML‑Vorlagen in `app/templates` lassen sich mit CSS erweitern. Sie können auch weitere Diagramme oder Tabellen einbinden.
- **Erweiterungen:** Für komplexere Reports können Sie PDF‑Generierung, Authentifizierung oder Datenbank‑Anbindung hinzufügen.

## Lizenz

Dieses Projekt steht unter der MIT‑Lizenz; siehe die Datei `LICENSE` (falls vorhanden) für weitere Informationen.